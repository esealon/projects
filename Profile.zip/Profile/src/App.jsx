import React, { useState } from 'react';
import NavBar from './NavBar';
import Typography from '@mui/material/Typography';
import Box from '@mui/material/Box';
import Profile from './Profile';
import HandleNavBar from './HandleNavBar';

function App() {
return (
  <HandleNavBar />
)
}

export default App;
