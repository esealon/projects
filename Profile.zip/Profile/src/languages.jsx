import React from "react";
import { tableBodyClasses, Typography } from "@mui/material";
import CenteredBox from "./CenteredBox";
import Divider from "@mui/material/Divider";
import Box from "@mui/material/Box";
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  CircularProgress,
} from "@mui/material";
import "./styles.css";

const Languages = () => {
  return (
    <CenteredBox>
      <div className="main-page">
        <h1 style={{ textAlign: "center" }}>Languages</h1>
        <Divider sx={{ my: 2 }} />
        <TableContainer
          component={Paper}
          sx={{
            width: {
              xs: "80%", // Responsive width for small screens
              sm: "50%",
              md: "40%",
              lg: "40%",
              xl: "40%",
            },
            maxHeight: "500px",
            margin: "0 auto",
            boxShadow: 3,
          }}
        >
          <Table>
            <TableHead>
              <TableRow>
                <TableCell id="CenterBold">Language</TableCell>
                <TableCell id="CenterBold">Level</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              <TableRow>
                <TableCell>Spanish</TableCell>
                <TableCell>Native</TableCell>
              </TableRow>
              <TableRow>
                <TableCell>English</TableCell>
                <TableCell>Proficient</TableCell>
              </TableRow>
              <TableRow>
                <TableCell>Estonian</TableCell>
                <TableCell>Proficient</TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </TableContainer>
      </div>
    </CenteredBox>
  );
};

export default Languages;
