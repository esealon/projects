import React from "react";
import Box from "@mui/material/Box";
import { Grid } from "@mui/material";
import Paper from "@mui/material/Paper";

const CenteredBox = ({ children, ...props }) => {
  return (
    <Box
    sx={{
      display: 'flex',
      justifyContent: 'center',  // Center horizontally
      width: '100%',             // Full width of the parent container
      backgroundColor: 'background.paper', // Optional: set background color for the Box
      width: {
        xs: '100%',  // Responsive width for small screens
        sm: '100%',
        md: '100%',
        lg: '100%',
        xl: '100%',
      },
    }}
  >
    <Paper
      elevation={3}
      sx={{
        width: 1000,
        padding: 3,
        backgroundColor: "lightblue",
        maxWidth: 1200,  // Maximum width of the Paper
        borderRadius: 2, // Rounded corners
      }}
    >
          {children}
        </Paper>
      
    </Box>
  );
};
export default CenteredBox;
