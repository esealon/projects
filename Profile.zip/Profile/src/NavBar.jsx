import React from "react";
import AppBar from "@mui/material/AppBar";
import Toolbar from "@mui/material/Toolbar";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import IconButton from "@mui/material/IconButton";
import MenuIcon from "@mui/icons-material/Menu";
import { useEffect } from "react";
import Profile from "./Profile";
import { Box } from "@mui/material";
import AccountBoxTwoToneIcon from '@mui/icons-material/AccountBoxTwoTone';

const NavBar = ({ onButtonClick }) => {
  return (
    <AppBar position="static" sx={{borderRadius: 2}}>
      <Toolbar style={{ display: "flex", justifyContent: "space-between" }}>
        <IconButton edge="start" color="inherit" aria-label="menu">
          <AccountBoxTwoToneIcon/>Sergio Alonzo
        </IconButton>
        <Button color="inherit" onClick={() => onButtonClick("Profile")}>
          Profile
        </Button>
        <Button color="inherit" onClick={() => onButtonClick("WorkExperience")}>
          Work Experience
        </Button>
        <Button color="inherit" onClick={() => onButtonClick("Education")}>
          Education
        </Button>
        <Button color="inherit" onClick={() => onButtonClick("Languages")}>
          Languages
        </Button>
      </Toolbar>
    </AppBar>
  );
};

export default NavBar;



